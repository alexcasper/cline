#!/usr/bin/env python3
"""Generate SwarmShape paper figures (house style).

House style: 1px #000000 strokes, round caps/joins, white fills, single accent
#E8590C. Nodes = mechanics only (no empirical stats in artwork). Accent marks
the rogue-seat placement rule (highest-degree vertex, tie -> lowest index).
All graph edges are real: canonical shapes follow agora/agora/topology.py
channel specs; family exemplars are actual graph_edges from
agora/runs/shape_grid/*clean__seed42/summary.json.
"""
import json

BLACK, ACCENT, WHITE = "#000000", "#E8590C", "#FFFFFF"
W, H = 760, 230


def svg_header(w, h):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" '
            f'width="{w}" height="{h}">\n'
            '<g stroke="#000000" stroke-width="1" stroke-linecap="round" '
            'stroke-linejoin="round" fill="none">')


def node(x, y, accent=False, r=5):
    fill = ACCENT if accent else WHITE
    stroke = ACCENT if accent else BLACK
    return (f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="{fill}" '
            f'stroke="{stroke}"/>')


def edge(x1, y1, x2, y2):
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}"/>'


def label(x, y, text):
    return (f'</g>\n<text x="{x}" y="{y}" font-family="Helvetica,Arial" '
            f'font-size="12" fill="#000000" text-anchor="middle">{text}</text>\n'
            '<g stroke="#000000" stroke-width="1" stroke-linecap="round" '
            'stroke-linejoin="round" fill="none">')


def circle_layout(n, cx, cy, rx, ry):
    import math
    return [(cx + rx * math.cos(2 * math.pi * i / n - math.pi / 2),
             cy + ry * math.sin(2 * math.pi * i / n - math.pi / 2))
            for i in range(n)]


def rogue_index(edges, n):
    deg = [0] * n
    for a, b in edges:
        deg[a] += 1
        deg[b] += 1
    return deg.index(max(deg))


def panel(out, edges, n, cx, cy, rx, ry, title, pos="circle", accent=None):
    if pos == "circle":
        pts = circle_layout(n, cx, cy, rx, ry)
    else:
        pts = pos
    acc = accent if accent is not None else rogue_index(edges, n)
    for a, b in edges:
        out.append(edge(*pts[a], *pts[b]))
    for i, p in enumerate(pts):
        out.append(node(p[0], p[1], accent=(i == acc)))
    out.append(label(cx, cy + ry + 26, title))


def canonical_fig(path):
    """Fig 1: the four canonical shapes of the shape_rogue multiseed run (n=8)."""
    n = 8
    out = [svg_header(W, H)]
    m = W / 4
    # flat: public board = everyone talks to everyone (complete graph)
    pts = circle_layout(n, m * 0.5, 105, 70, 62)
    for i in range(n):
        for j in range(i + 1, n):
            out.append(edge(*pts[i], *pts[j]))
    for i, p in enumerate(pts):
        out.append(node(p[0], p[1], accent=(i == 0)))
    out.append(label(m * 0.5, 222, "flat (public board)"))
    # ring: cycle
    pts = circle_layout(n, m * 1.5, 105, 70, 62)
    for i in range(n):
        out.append(edge(*pts[i], *pts[(i + 1) % n]))
    for i, p in enumerate(pts):
        out.append(node(p[0], p[1], accent=(i == 0)))
    out.append(label(m * 1.5, 222, "ring"))
    # star: hub + spokes (accent = hub; spokes write hub, hub broadcasts)
    hub = (m * 2.5, 105)
    pts = circle_layout(n - 1, m * 2.5, 105, 70, 62)
    for p in pts:
        out.append(edge(*hub, *p))
    for p in pts:
        out.append(node(p[0], p[1]))
    out.append(node(*hub, accent=True))
    out.append(label(m * 2.5, 222, "star (hub broadcast)"))
    # hierarchy: 2 managers, 3 supervisors, 3 workers (agora hierarchy spec)
    mans = [(m * 3.5 - 40, 55), (m * 3.5 + 40, 55)]
    sups = [(m * 3.5 - 80, 120), (m * 3.5, 120), (m * 3.5 + 80, 120)]
    works = [(m * 3.5 - 90, 185), (m * 3.5, 185), (m * 3.5 + 90, 185)]
    allp = mans + sups + works
    edges = []
    for s in sups:                      # managers <-> supervisors
        for mn in mans:
            edges.append((s, mn))
    for wk in works:                    # workers <-> supervisors
        for s in sups:
            edges.append((wk, s))
    for a, b in edges:
        out.append(edge(*a, *b))
    for i, p in enumerate(allp):
        out.append(node(p[0], p[1], accent=(i == 0)))  # rogue = a manager
    out.append(label(m * 3.5, 222, "hierarchy (2-3-3)"))
    out.append("</g>\n</svg>\n")
    open(path, "w").write("".join(out))


def grid_exemplars_fig(path):
    """Fig 2: real graph_edges exemplars, one per family of the 57-graph space."""
    base = "/mnt/d/ops/apart/agora/runs/shape_grid"
    picks = {
        "exhaustive n=5": ("price_war__n5_g1_exact_clean__seed42", "circle"),
        "scale-free m=2, n=13": ("price_war__n13_g0_scale_free_m2_clean__seed42", "circle"),
        "chain+skips, n=13": ("price_war__n13_g1_chain_skips_clean__seed42", "chain"),
        "G(n,p=0.20), n=12": ("price_war__n12_g0_gnp_0.20_clean__seed42", "circle"),
        "G(n,p=0.35), n=15": ("price_war__n15_g1_gnp_0.35_clean__seed42", "circle"),
    }
    panels = []
    for title, (run, pos) in picks.items():
        s = json.load(open(f"{base}/{run}/summary.json"))
        e = [tuple(x) for x in s["arm"]["graph_edges"]]
        n = max(max(a, b) for a, b in e) + 1
        panels.append((title, e, n, pos))
    w, h = W, 460
    cols, rows = 3, 2
    cw, ch = w / cols, h / rows
    out = [svg_header(w, h)]
    for k, (title, e, n, pos) in enumerate(panels):
        cx = cw * (k % cols) + cw / 2
        cy = ch * (k // cols) + ch / 2 - 8
        rx, ry = cw / 2 - 28, ch / 2 - 32
        pts = circle_layout(n, cx, cy, rx, ry)
        if pos == "chain":  # chain layout: ordered left-to-right
            pts = [(cx - rx + (2 * rx) * (i / (n - 1)), cy) for i in range(n)]
        acc = rogue_index(e, n)
        for a, b in e:
            out.append(edge(*pts[a], *pts[b]))
        for i, p in enumerate(pts):
            out.append(node(p[0], p[1], accent=(i == acc), r=4))
        out.append(label(cx, ch * (k // cols) + ch - 10, title))
    out.append("</g>\n</svg>\n")
    open(path, "w").write("".join(out))


if __name__ == "__main__":
    import os
    os.makedirs("figures", exist_ok=True)
    canonical_fig("figures/fig_shapes_canonical.svg")
    grid_exemplars_fig("figures/fig_grid_exemplars.svg")
    print("written")
