#!/usr/bin/env python3
"""Referee-response analyses (v2, defensive None handling)."""
import csv, json, math, glob, statistics as st
from collections import defaultdict

DUSK = "/mnt/d/ops/apart/agora/runs/shape_grid"
MODAL = "/mnt/d/ops/apart/agora/runs-modal/shape-grid-20261107/shape-grid-20261107/qwen3.5-4b"

def rank(xs):
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    r = [0.0]*len(xs); i = 0
    while i < len(order):
        j = i
        while j+1 < len(order) and xs[order[j+1]] == xs[order[i]]:
            j += 1
        for k in range(i, j+1):
            r[order[k]] = (i+j)/2 + 1
        i = j+1
    return r

def spearman(x, y):
    pairs = [(a,b) for a,b in zip(x,y) if a is not None and b is not None]
    if len(pairs) < 5: return None, len(pairs)
    x, y = [a for a,_ in pairs], [b for _,b in pairs]
    rx, ry = rank(x), rank(y)
    mx, my = sum(rx)/len(rx), sum(ry)/len(ry)
    cov = sum((a-mx)*(b-my) for a,b in zip(rx,ry))
    vx = math.sqrt(sum((a-mx)**2 for a in rx)); vy = math.sqrt(sum((b-my)**2 for b in ry))
    return (cov/(vx*vy) if vx and vy else None), len(pairs)

def partial_spearman(x, y, z):
    ok = [(a,b,c) for a,b,c in zip(x,y,z) if None not in (a,b,c)]
    if len(ok) < 5: return None
    x = [t[0] for t in ok]; y = [t[1] for t in ok]; z = [t[2] for t in ok]
    rx, ry, rz = rank(x), rank(y), rank(z)
    mz = sum(rz)/len(rz)
    def resid(r):
        mr = sum(r)/len(r)
        b = sum((zz-mz)*(rr-mr) for zz,rr in zip(rz,r)) / max(sum((zz-mz)**2 for zz in rz), 1e-12)
        return [rr - mr - b*(zz-mz) for rr,zz in zip(r,rz)]
    ex, ey = resid(rx), resid(ry)
    mx, my = sum(ex)/len(ex), sum(ey)/len(ey)
    cov = sum((a-mx)*(b-my) for a,b in zip(ex,ey))
    vx = math.sqrt(sum((a-mx)**2 for a in ex)); vy = math.sqrt(sum((b-my)**2 for b in ey))
    return cov/(vx*vy) if vx and vy else None

def num(v):
    try: return float(v)
    except (TypeError, ValueError): return None

def load(run):
    rows = []
    for r in csv.DictReader(open(run+"/games.csv")):
        if not r.get("arm"): continue
        gated = num(r.get("missing_action_rate") or 0) <= 0.10
        rows.append({"arm": r["arm"], "graph": r["graph"], "game": r["game"],
                     "n": num(r["n"]), "gated": gated,
                     "viol": num(r["violation_rate"]), "seat": num(r["rogue_seat_violation_rate"]),
                     "hhi": num(r["takeover_hhi"]), "uni": num(r["uniform_hhi"]),
                     "maxdeg": num(r["max_degree"]), "invalid": num(r["invalid_tool_call_rate"]),
                     "trunc": num(r["truncated_rate"]), "family": r["family"]})
    return [r for r in rows if r["gated"]], rows

def pairs_with_hhi(rows):
    by = defaultdict(dict)
    for r in rows:
        if r["gated"]: by[r["graph"]][r["arm"]] = r
    out = {}
    for g, d in by.items():
        if "clean" in d and "rogue" in d and d["clean"]["hhi"] is not None and d["clean"]["uni"] is not None:
            out[g] = d
    return out

dusk_gated, dusk_all = load(DUSK)
mod_gated, mod_all = load(MODAL)
print(f"gated: dusk {len(dusk_gated)}, modal {len(mod_gated)}")

print("\n[A] same-graph parity")
dpairs = pairs_with_hhi(dusk_gated)
mpairs = pairs_with_hhi(mod_gated)
common = sorted(set(dpairs) & set(mpairs))
x_d = [dpairs[g]["clean"]["hhi"] - dpairs[g]["clean"]["uni"] for g in common]
x_m = [mpairs[g]["clean"]["hhi"] - mpairs[g]["clean"]["uni"] for g in common]
ns = [dpairs[g]["clean"]["n"] for g in common]
r1,_ = spearman(x_d, ns); r2,_ = spearman(x_m, ns)
print(f"  common graphs with HHI: {len(common)}")
print(f"  rho(n) on common set: dusk {r1:.3f}, modal {r2:.3f}")
allm = [r for r in mod_gated if r["arm"]=="clean" and r["hhi"] is not None]
r3,_ = spearman([r["hhi"]-r["uni"] for r in allm], [r["n"] for r in allm])
alld = [r for r in dusk_gated if r["arm"]=="clean" and r["hhi"] is not None]
r4,_ = spearman([r["hhi"]-r["uni"] for r in alld], [r["n"] for r in alld])
print(f"  rho(n) full clean sets: dusk {r4:.3f} (n={len(alld)}), modal {r3:.3f} (n={len(allm)})")
dc = st.mean([r["viol"] for r in dusk_gated if r["arm"]=="clean"])
mc = st.mean([r["viol"] for r in mod_gated if r["arm"]=="clean"])
gcommon = {g for g in common}
dc2 = st.mean([dpairs[g]["clean"]["viol"] for g in common])
mc2 = st.mean([mpairs[g]["clean"]["viol"] for g in common])
print(f"  clean base: full gated dusk {dc:.4f} / modal {mc:.4f}; common-graphs dusk {dc2:.4f} / modal {mc2:.4f}")

print("\n[B] hubness: raw + partial given n (clean arms)")
for host, rows in [("dusk", dusk_gated), ("modal", mod_gated)]:
    cl = [r for r in rows if r["arm"]=="clean" and r["hhi"] is not None]
    exc = [r["hhi"]-r["uni"] for r in cl]
    ns = [r["n"] for r in cl]
    hubn = [r["maxdeg"]/(r["n"]-1) if r["n"]>1 else None for r in cl]
    md = [r["maxdeg"] for r in cl]
    a,_ = spearman(hubn, exc); b = partial_spearman(hubn, exc, ns)
    c = partial_spearman(md, exc, ns)
    d,_ = spearman(ns, exc)
    print(f"  {host}: rho(hub_norm)={a:.3f} partial(hub|n)={b:.3f} partial(maxdeg|n)={c:.3f} rho(n)={d:.3f}")

print("\n[C] neighbor-uniform follow null")
def null_hhi(edges, n):
    adj = defaultdict(set)
    for a,b in edges: adj[a].add(b); adj[b].add(a)
    w = [0.0]*n
    for i in range(n):
        if adj[i]:
            for j in adj[i]: w[j] += 1.0/len(adj[i])
    tot = sum(w)
    return sum((x/tot)**2 for x in w) if tot else None

for host, run in [("dusk", DUSK), ("modal", MODAL)]:
    res = []
    for p in glob.glob(run+"/price_war__*/summary.json"):
        s = json.load(open(p)); arm = s["arm"]
        nm = arm["name"]
        if not (nm.endswith("_clean") or nm.endswith("_rogue")): continue
        edges = arm.get("graph_edges") or []
        pi = s.get("proposal_influence") or {}
        if not edges or pi.get("takeover_hhi") is None or pi.get("uniform_hhi") in (None, 0): continue
        n = max(max(a,b) for a,b in edges)+1
        nh = null_hhi(edges, n)
        if nh: res.append((n, pi["takeover_hhi"]/nh, pi["takeover_hhi"]-pi["uniform_hhi"]))
    ratios = [x[1] for x in res]; ns = [x[0] for x in res]
    beat = sum(1 for x in res if x[2] > 0)
    rr,_ = spearman(ns, ratios)
    print(f"  {host}: n={len(res)} games | observed>uniform: {beat} ({beat/len(res)*100:.0f}%) | "
          f"obs/null mean {st.mean(ratios):.2f} median {st.median(ratios):.2f} | rho(n) of obs/null: {rr:.3f}")

print("\n[D/E] ratio>1 count, family counts")
for host, rows in [("dusk", dusk_gated), ("modal", mod_gated)]:
    hh = [r for r in rows if r["hhi"] is not None and r["uni"] is not None]
    above = sum(1 for r in hh if r["hhi"] > r["uni"])
    fam = defaultdict(int)
    for r in hh: fam[r["family"]] += 1
    print(f"  {host}: hhi>uniform {above}/{len(hh)}; by family {dict(fam)}")

print("\n[F] same-seat comparison (dusk)")
dsums = {}
for p in glob.glob(DUSK+"/price_war__*/summary.json"):
    s = json.load(open(p)); dsums[s["arm"]["name"]] = s
clean_seat, rogue_seat = [], []
for nm, s in dsums.items():
    if not nm.endswith("_rogue"): continue
    seat = s["arm"].get("rogue")
    c = dsums.get(nm[:-6]+"_clean")
    if not c or not seat: continue
    vc = c.get("valid_rounds") or 0
    vr = s.get("valid_rounds") or 0
    if vc: clean_seat.append((c.get("rogue",{}).get("by_agent") or {}).get(seat,0)/vc)
    if vr: rogue_seat.append((s.get("rogue",{}).get("by_agent") or {}).get(seat,0)/vr)
print(f"  same position: clean {st.mean(clean_seat):.4f} vs rogue-instructed {st.mean(rogue_seat):.4f} "
      f"(n={len(clean_seat)} pairs)")

print("\n[G] serving noise vs violations (dusk)")
cl = [r for r in dusk_gated if r["arm"]=="clean" and r["viol"] is not None]
for k in ("invalid","trunc"):
    rr,kn = spearman([r[k] for r in cl], [r["viol"] for r in cl])
    print(f"  spearman(viol, {k}) = {rr:.3f} (n={kn})")
hi = [r for r in cl if (r["invalid"] or 0) > 0.20]; lo = [r for r in cl if (r["invalid"] or 0) <= 0.20]
print(f"  mean viol: invalid>0.20 games {st.mean([r['viol'] for r in hi]):.4f} (n={len(hi)}) vs rest {st.mean([r['viol'] for r in lo]):.4f} (n={len(lo)})")
